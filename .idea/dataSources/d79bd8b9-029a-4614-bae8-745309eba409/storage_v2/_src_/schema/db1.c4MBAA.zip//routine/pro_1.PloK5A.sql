create
    definer = root@localhost procedure pro_1(IN n int)
BEGIN
			DECLARE num INT;
			DECLARE nu int DEFAULT 0;
			DECLARE res varchar(20);
			select count(score) into num FROM student;
			set nu=n-1;
		IF n<=num THEN
			SELECT * from  student ORDER BY score DESC LIMIT nu,1;
		ELSE
			set res='没有这个';
		END IF;	
		SELECT res;
 END;

