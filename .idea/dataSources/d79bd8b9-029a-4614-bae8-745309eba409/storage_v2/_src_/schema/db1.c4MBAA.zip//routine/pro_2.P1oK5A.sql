create
    definer = root@localhost function pro_2(n int) returns varchar(20)
BEGIN
			DECLARE num,sscore INT;
			DECLARE res varchar(20);
			select count(score) into num FROM student;
			set n=n-1;
		IF n<=num THEN
			SELECT score into sscore from  student ORDER BY score  LIMIT n,1;
			SET res=CONCAT('第',n+1,'个学生的成绩为',sscore);
		ELSE
			set res='没有这个';
		END IF;	
		RETURN res;
 END;

